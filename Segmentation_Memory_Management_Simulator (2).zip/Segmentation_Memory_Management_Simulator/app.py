from contextlib import closing
from pathlib import Path
import re
import sqlite3

from flask import Flask, g, jsonify, render_template, request


BASE_DIR = Path(__file__).resolve().parent
MAX_SQLITE_INTEGER = 2**63 - 1

app = Flask(__name__, static_folder="templates/static", static_url_path="/static")
app.config["DATABASE"] = str(BASE_DIR / "simulator.db")
app.config["TEMPLATES_AUTO_RELOAD"] = True


def get_db():
    if "db" not in g:
        connection = sqlite3.connect(app.config["DATABASE"])
        connection.row_factory = sqlite3.Row
        g.db = connection
    return g.db


@app.teardown_appcontext
def close_db(_error=None):
    connection = g.pop("db", None)
    if connection is not None:
        connection.close()


def init_db():
    with closing(sqlite3.connect(app.config["DATABASE"])) as connection:
        connection.execute("PRAGMA foreign_keys = ON")
        connection.execute("""
            CREATE TABLE IF NOT EXISTS segments (
                segment_no INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                base INTEGER NOT NULL,
                segment_limit INTEGER NOT NULL
            )
        """)
        connection.execute("""
            CREATE TABLE IF NOT EXISTS history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                segment_no INTEGER NOT NULL,
                offset_value INTEGER NOT NULL,
                physical_address INTEGER,
                status TEXT NOT NULL,
                base_address INTEGER,
                created_at TEXT
            )
        """)

        # Migrate databases created by earlier versions without removing user data.
        columns = {row[1] for row in connection.execute("PRAGMA table_info(history)")}
        if "base_address" not in columns:
            connection.execute("ALTER TABLE history ADD COLUMN base_address INTEGER")
        if "created_at" not in columns:
            connection.execute("ALTER TABLE history ADD COLUMN created_at TEXT")
        connection.commit()


def json_body():
    value = request.get_json(silent=True)
    return value if isinstance(value, dict) else {}


def whole_number(value):
    """Accept JSON integers and digit-only strings, but reject bools and fractions."""
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        number = value
    elif isinstance(value, str) and re.fullmatch(r"\d+", value.strip()):
        number = int(value.strip())
    else:
        return None
    if number < 0 or number > MAX_SQLITE_INTEGER:
        return None
    return number


@app.route("/")
def home():
    return render_template("index.html")


@app.get("/api/segments")
def get_segments():
    rows = get_db().execute(
        "SELECT segment_no, name, base, segment_limit FROM segments ORDER BY segment_no"
    ).fetchall()
    return jsonify([dict(row) for row in rows])


@app.post("/api/segments")
def save_segment():
    data = json_body()
    number = whole_number(data.get("segment_no"))
    base = whole_number(data.get("base"))
    limit = whole_number(data.get("limit"))
    name = data.get("name")

    if (number is None or base is None or limit is None or limit == 0
            or not isinstance(name, str) or not name.strip() or len(name.strip()) > 40
            or base + limit - 1 > MAX_SQLITE_INTEGER):
        return jsonify(error="Enter a non-negative segment number and base, a name up to 40 characters, and a positive whole-number limit."), 400

    get_db().execute("""
        INSERT INTO segments (segment_no, name, base, segment_limit)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(segment_no) DO UPDATE SET
            name=excluded.name,
            base=excluded.base,
            segment_limit=excluded.segment_limit
    """, (number, name.strip(), base, limit))
    get_db().commit()
    return jsonify(message="Segment saved successfully")


@app.delete("/api/segments/<int:number>")
def delete_segment(number):
    get_db().execute("DELETE FROM segments WHERE segment_no = ?", (number,))
    get_db().commit()
    return jsonify(message="Segment deleted")


@app.post("/api/translate")
def translate():
    data = json_body()
    number = whole_number(data.get("segment_no"))
    offset = whole_number(data.get("offset"))
    if number is None or offset is None:
        return jsonify(error="Enter a non-negative whole segment number and offset."), 400

    connection = get_db()
    segment = connection.execute(
        "SELECT name, base, segment_limit FROM segments WHERE segment_no = ?", (number,)
    ).fetchone()

    if segment is None:
        status, physical, base = "Invalid segment", None, None
        result = {"status": status, "message": f"Segment {number} does not exist."}
    elif offset >= segment["segment_limit"]:
        status, physical, base = "Out of bounds", None, segment["base"]
        result = {"status": status, "message": f"Offset {offset} is outside the segment limit of {segment['segment_limit']}."}
    else:
        status, base = "Valid", segment["base"]
        physical = base + offset
        result = {
            "status": status,
            "segment_name": segment["name"],
            "base": base,
            "limit": segment["segment_limit"],
            "offset": offset,
            "physical_address": physical,
        }

    connection.execute("""
        INSERT INTO history
            (segment_no, offset_value, physical_address, status, base_address, created_at)
        VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
    """, (number, offset, physical, status, base))
    connection.commit()
    return jsonify(result)


@app.get("/api/history")
def get_history():
    rows = get_db().execute("""
        SELECT id, segment_no, offset_value, physical_address, status, base_address, created_at
        FROM history ORDER BY id DESC
    """).fetchall()
    return jsonify([dict(row) for row in rows])


@app.post("/api/history/clear")
def clear_history():
    connection = get_db()
    connection.execute("DELETE FROM history")
    connection.execute("DELETE FROM sqlite_sequence WHERE name = 'history'")
    connection.commit()
    return jsonify(message="Translation history cleared")


@app.post("/api/reset")
def reset():
    connection = get_db()
    connection.execute("DELETE FROM segments")
    connection.execute("DELETE FROM history")
    connection.execute("DELETE FROM sqlite_sequence WHERE name = 'history'")
    connection.commit()
    return jsonify(message="Simulator reset")


init_db()


if __name__ == "__main__":
    app.run()

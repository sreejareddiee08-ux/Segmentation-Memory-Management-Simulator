let segments = Object.create(null);
let history = [];
let validCount = 0;
let faultCount = 0;

const viewTitles = {
  dashboard: 'Dashboard',
  segments: 'Manage segments',
  translate: 'Address translation',
  'memory-view': 'Physical memory',
  'history-view': 'Translation history',
  theory: 'Project Theory'
};

async function api(path, options = {}) {
  const response = await fetch(path, {
    ...options,
    headers: { ...(options.body ? { 'Content-Type': 'application/json' } : {}), ...options.headers }
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload.error || payload.message || `Request failed (${response.status}).`);
  return payload;
}

function showView(view, updateHash = true) {
  if (!viewTitles[view]) view = 'dashboard';
  document.querySelectorAll('.page-view').forEach(page => page.classList.toggle('active', page.id === `view-${view}`));
  document.querySelectorAll('.nav-link').forEach(link => {
    const selected = link.dataset.view === view;
    link.classList.toggle('active', selected);
    if (selected) link.setAttribute('aria-current', 'page');
    else link.removeAttribute('aria-current');
  });
  document.getElementById('pageTitle').textContent = viewTitles[view];
  if (updateHash && location.hash !== `#${view}`) window.history.replaceState(null, '', `#${view}`);
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function startSimulation() {
  document.getElementById('startScreen').hidden = true;
  document.getElementById('appShell').classList.add('signed-in');
  setTodayLabel();
  showView('dashboard');
}

function returnToStart() {
  document.getElementById('appShell').classList.remove('signed-in');
  document.getElementById('startScreen').hidden = false;
}

function setTodayLabel() {
  document.getElementById('todayLabel').textContent = new Intl.DateTimeFormat(undefined, { dateStyle: 'medium' }).format(new Date());
}

async function exportHistory() {
  try {
    await loadData();
    const rows = [['No.', 'Segment', 'Offset', 'Base', 'Physical address', 'Status', 'Time']];
    [...history].reverse().forEach((item, index) => {
      rows.push([index + 1, item.seg, item.offset, item.base, item.physical, item.status, item.timestamp]);
    });
    const csv = rows.map(row => row.map(value => `"${String(value ?? '').replace(/"/g, '""')}"`).join(',')).join('\r\n');
    const file = new Blob([csv], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(file);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'memory-lab-translation-history.csv';
    link.click();
    URL.revokeObjectURL(url);
  } catch (error) {
    alert(`Could not export history: ${error.message}`);
  }
}

function readInteger(id) {
  const raw = document.getElementById(id).value.trim();
  if (raw === '') return null;
  const value = Number(raw);
  return Number.isSafeInteger(value) ? value : null;
}

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[char]);
}

function normalizeHistory(row) {
  return {
    id: row.id,
    seg: row.segment_no,
    offset: row.offset_value,
    base: row.base_address ?? '—',
    physical: row.physical_address ?? '—',
    status: row.status,
    ok: row.status === 'Valid',
    timestamp: row.created_at || ''
  };
}

async function loadData(highlightNo = null) {
  const [segmentRows, historyRows] = await Promise.all([api('/api/segments'), api('/api/history')]);
  segments = Object.create(null);
  segmentRows.forEach(row => {
    segments[row.segment_no] = { name: row.name, base: row.base, limit: row.segment_limit };
  });
  history = historyRows.map(normalizeHistory);
  validCount = history.filter(item => item.ok).length;
  faultCount = history.filter(item => !item.ok).length;
  render(highlightNo);
}

async function addSegment() {
  const no = readInteger('segNo');
  const name = document.getElementById('segName').value.trim();
  const base = readInteger('base');
  const limit = readInteger('limit');
  if (no === null || no < 0 || !name || name.length > 40 || base === null || base < 0 || limit === null || limit <= 0 || !Number.isSafeInteger(base + limit - 1)) {
    alert('Enter a non-negative whole segment number and base, a name up to 40 characters, and a positive whole-number limit.');
    return;
  }
  try {
    await api('/api/segments', { method: 'POST', body: JSON.stringify({ segment_no: no, name, base, limit }) });
    clearForm();
    await loadData();
  } catch (error) {
    alert(`Could not save segment: ${error.message}`);
  }
}

async function deleteSegment(no) {
  if (!window.confirm(`Delete segment ${no}?`)) return;
  try {
    await api(`/api/segments/${no}`, { method: 'DELETE' });
    await loadData();
  } catch (error) {
    alert(`Could not delete segment: ${error.message}`);
  }
}

function editSegment(no) {
  const segment = segments[no];
  if (!segment) return;
  document.getElementById('segNo').value = no;
  document.getElementById('segName').value = segment.name;
  document.getElementById('base').value = segment.base;
  document.getElementById('limit').value = segment.limit;
  showView('segments');
  document.getElementById('segName').focus();
}

async function translateAddress() {
  const no = readInteger('translateSeg');
  const offset = readInteger('offset');
  if (no === null || no < 0 || offset === null || offset < 0) {
    showResult('Enter a non-negative whole segment number and offset.', false);
    return;
  }
  try {
    const result = await api('/api/translate', { method: 'POST', body: JSON.stringify({ segment_no: no, offset }) });
    if (result.status !== 'Valid') {
      showResult(`<b>SEGMENTATION FAULT</b><br>${escapeHTML(result.message)}`, false);
      await loadData();
      return;
    }
    showResult(`<b>VALID ADDRESS</b><br>Segment: ${escapeHTML(result.segment_name)} (${no})<br>Base: ${result.base} &nbsp; · &nbsp; Limit: ${result.limit}<br>Offset: ${offset}<br><strong>Physical address = ${result.base} + ${offset} = ${result.physical_address}</strong>`, true);
    await loadData(no);
  } catch (error) {
    showResult(escapeHTML(error.message), false);
  }
}

function showResult(message, ok) {
  const result = document.getElementById('result');
  result.className = `result ${ok ? 'success' : 'error'}`;
  result.innerHTML = message;
}

function render(highlightNo = null) {
  const keys = Object.keys(segments).map(Number).sort((a, b) => a - b);
  const segmentTable = document.getElementById('segmentTable');
  segmentTable.innerHTML = keys.length ? keys.map(no => {
    const segment = segments[no];
    return `<tr><td>${no}</td><td>${escapeHTML(segment.name)}</td><td>${segment.base}</td><td>${segment.limit}</td><td>${segment.base + segment.limit - 1}</td><td><button type="button" class="small" onclick="editSegment(${no})">Edit</button> <button type="button" class="small danger" onclick="deleteSegment(${no})">Delete</button></td></tr>`;
  }).join('') : '<tr><td colspan="6" class="empty-cell">No segments yet. Add a segment or load the sample data.</td></tr>';

  document.getElementById('memory').innerHTML = keys.length ? keys.map(no => {
    const segment = segments[no];
    return `<article class="segment-block ${highlightNo === no ? 'highlight' : ''}"><h3>Segment ${no}</h3><p><b>${escapeHTML(segment.name)}</b></p><p>Base: ${segment.base}</p><p>Limit: ${segment.limit}</p><p>Range: ${segment.base}–${segment.base + segment.limit - 1}</p></article>`;
  }).join('') : '<p class="memory-empty">No allocated segments yet.</p>';

  document.getElementById('historyTable').innerHTML = history.length ? history.map((item, index) =>
    `<tr><td>${history.length - index}</td><td>${item.seg}</td><td>${item.offset}</td><td>${item.base}</td><td>${item.physical}</td><td>${escapeHTML(item.status)}</td></tr>`
  ).join('') : '<tr><td colspan="6" class="empty-cell">Your address translations will appear here.</td></tr>';

  document.getElementById('historyCount').textContent = `${history.length} ${history.length === 1 ? 'entry' : 'entries'}`;
  document.getElementById('segmentCountLabel').textContent = `${keys.length} ${keys.length === 1 ? 'segment' : 'segments'}`;
  document.getElementById('memorySegmentCount').textContent = `${keys.length} allocated ${keys.length === 1 ? 'segment' : 'segments'}`;
  document.getElementById('totalSegments').textContent = keys.length;
  document.getElementById('validCount').textContent = validCount;
  document.getElementById('faultCount').textContent = faultCount;
  document.getElementById('healthSegments').textContent = keys.length;
  document.getElementById('healthValid').textContent = validCount;
  document.getElementById('healthFaults').textContent = faultCount;
  const attempts = validCount + faultCount;
  document.getElementById('successRate').textContent = attempts ? `${Math.round(validCount / attempts * 100)}%` : '—%';
  document.getElementById('dashboardSegmentSummary').textContent = keys.length
    ? keys.map(no => `${no}: ${segments[no].name}`).join(' · ')
    : 'No segments added yet';
  document.getElementById('dashboardHistory').innerHTML = history.length ? history.slice(0, 4).map(item =>
    `<tr><td>${item.seg}</td><td>${item.offset}</td><td>${item.physical}</td><td><span class="status-pill ${item.ok ? 'status-valid' : 'status-fault'}">${escapeHTML(item.status)}</span></td></tr>`
  ).join('') : '<tr><td colspan="4" class="empty-cell">No translations yet. Your recent results will appear here.</td></tr>';
  document.getElementById('translationSegments').innerHTML = keys.length ? keys.map(no => {
    const segment = segments[no];
    return `<div class="mini-segment"><strong>Segment ${no} &middot; ${escapeHTML(segment.name)}</strong><span>Base ${segment.base} &nbsp; / &nbsp; Limit ${segment.limit}</span></div>`;
  }).join('') : '<p class="memory-empty">Add a segment before translating an address.</p>';
  renderActivityChart();
}

function renderActivityChart() {
  const now = new Date();
  const days = Array.from({ length: 7 }, (_, index) => {
    const date = new Date(now);
    date.setHours(0, 0, 0, 0);
    date.setDate(now.getDate() - (6 - index));
    const count = history.filter(item => {
      if (!item.timestamp) return false;
      const stamp = new Date(item.timestamp.replace(' ', 'T'));
      return stamp.getFullYear() === date.getFullYear() && stamp.getMonth() === date.getMonth() && stamp.getDate() === date.getDate();
    }).length;
    return { date, count };
  });
  const max = Math.max(1, ...days.map(day => day.count));
  document.getElementById('weeklyCount').textContent = `${days.reduce((sum, day) => sum + day.count, 0)} total`;
  document.getElementById('activityChart').innerHTML = days.map(day => {
    const height = day.count ? Math.max(12, day.count / max * 100) : 3;
    const label = new Intl.DateTimeFormat(undefined, { weekday: 'short' }).format(day.date);
    return `<div class="chart-column" title="${label}: ${day.count} translation${day.count === 1 ? '' : 's'}"><div class="chart-bar" style="height:${height}%"></div><span class="chart-label">${label}</span></div>`;
  }).join('');
}

function clearForm() {
  ['segNo', 'segName', 'base', 'limit'].forEach(id => { document.getElementById(id).value = ''; });
}

async function clearHistory() {
  try {
    await api('/api/history/clear', { method: 'POST' });
    const result = document.getElementById('result');
    result.className = 'result hidden';
    result.textContent = '';
    await loadData();
  } catch (error) {
    alert(`Could not clear history: ${error.message}`);
  }
}

async function loadSampleData() {
  const samples = [
    { segment_no: 0, name: 'Code', base: 1000, limit: 400 },
    { segment_no: 1, name: 'Data', base: 2400, limit: 300 },
    { segment_no: 2, name: 'Stack', base: 4100, limit: 200 }
  ];
  try {
    for (const sample of samples) await api('/api/segments', { method: 'POST', body: JSON.stringify(sample) });
    await loadData();
  } catch (error) {
    alert(`Could not load sample segments: ${error.message}`);
  }
}

async function resetSimulator() {
  if (!window.confirm('Reset all segments, statistics, and translation history?')) return;
  try {
    await api('/api/reset', { method: 'POST' });
    clearForm();
    document.getElementById('translateSeg').value = '';
    document.getElementById('offset').value = '';
    const result = document.getElementById('result');
    result.className = 'result hidden';
    result.textContent = '';
    await loadData();
  } catch (error) {
    alert(`Could not reset the simulator: ${error.message}`);
  }
}

window.addEventListener('hashchange', () => showView(location.hash.slice(1), false));
showView(location.hash.slice(1) || 'dashboard', false);
setTodayLabel();
loadData().catch(error => alert(`Could not load simulator data: ${error.message}`));

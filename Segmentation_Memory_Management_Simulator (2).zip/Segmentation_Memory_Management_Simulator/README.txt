SEGMENTATION MEMORY MANAGEMENT SIMULATOR

Run the web application:
1. Open a terminal in the project folder.
2. Install dependencies with: python -m pip install -r requirements.txt
3. Start the Flask server with: python app.py
4. Open http://127.0.0.1:5000 in your browser.
5. Click Simulate on the welcome screen to open the dashboard. No login is required.

Use the sidebar to switch between Dashboard, Manage segments, Address translation, Physical memory, Translation history, and Project Theory. Segment data and translations are saved to simulator.db. Export downloads the translation history as a CSV file.

Address translation is valid when the segment exists and offset < limit. The physical address is base + offset. Clear history removes translation records; Reset simulator removes both segments and history.

Project requirement covered:
Simulate segment table maintenance and logical-to-physical address translation for a segmented memory model.
